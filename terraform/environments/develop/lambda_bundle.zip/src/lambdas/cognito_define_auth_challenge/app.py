import os

from src.common.logging_utils import get_logger, log_event, log_response

logger = get_logger(__name__)


def _get_int(name, default):
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _set_custom_challenge(event):
    event.setdefault("response", {})
    event["response"]["issueTokens"] = False
    event["response"]["failAuthentication"] = False
    event["response"]["challengeName"] = "CUSTOM_CHALLENGE"


def handler(event, _context):
    log_event(logger, event, label="event_received")
    event.setdefault("request", {})
    session = event["request"].get("session") or []
    max_attempts = _get_int("OTP_MAX_ATTEMPTS", 3)

    if not session:
        _set_custom_challenge(event)
        log_response(logger, event)
        return event

    last = session[-1]
    if last.get("challengeName") == "CUSTOM_CHALLENGE" and last.get("challengeResult") is True:
        event.setdefault("response", {})
        event["response"]["issueTokens"] = True
        event["response"]["failAuthentication"] = False
        log_response(logger, event)
        return event

    if len(session) >= max_attempts:
        event.setdefault("response", {})
        event["response"]["issueTokens"] = False
        event["response"]["failAuthentication"] = True
        log_response(logger, event)
        return event

    _set_custom_challenge(event)
    log_response(logger, event)
    return event

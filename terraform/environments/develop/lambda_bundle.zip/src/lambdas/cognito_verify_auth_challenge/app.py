import time

from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)


def handler(event, _context):
    log_event(logger, event, label="event_received")
    event.setdefault("request", {})
    event.setdefault("response", {})

    private_params = event["request"].get("privateChallengeParameters") or {}
    expected = (private_params.get("answer") or "").strip()
    provided = (event["request"].get("challengeAnswer") or "").strip()

    expires_at = private_params.get("expires_at")
    if expires_at:
        try:
            if int(time.time()) > int(expires_at):
                event["response"]["answerCorrect"] = False
                log_response(logger, event)
                return event
        except (TypeError, ValueError):
            event["response"]["answerCorrect"] = False
            log_response(logger, event)
            return event

    event["response"]["answerCorrect"] = bool(expected) and expected == provided
    log_response(logger, event)
    return event

import os
from datetime import datetime, timezone

from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)


def handler(event, _context):
    log_event(logger, event, label="event_received")
    table_name = os.environ.get("TRIPS_TABLE_NAME", "")

    event["persisted"] = {
        "table": table_name or "UNCONFIGURED",
        "saved_at": datetime.now(timezone.utc).isoformat(),
    }
    log_response(logger, event)
    return event

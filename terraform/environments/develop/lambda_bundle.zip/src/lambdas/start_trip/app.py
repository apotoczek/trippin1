import json
import os

import boto3

from src.common.logging_utils import get_logger, log_event, log_response
from src.common.responses import json_response


logger = get_logger(__name__)
sfn = boto3.client("stepfunctions")
STATE_MACHINE_ARN = os.environ.get("STATE_MACHINE_ARN", "")


def handler(event, _context):
    log_event(logger, event, label="event_received")
    body = json.loads(event.get("body") or "{}")

    if not STATE_MACHINE_ARN:
        response = json_response(500, {"message": "STATE_MACHINE_ARN is not configured"})
        log_response(logger, response)
        return response

    response = sfn.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        input=json.dumps(body),
    )
    payload = json_response(
        202,
        {
            "message": "trip workflow started",
            "execution_arn": response["executionArn"],
            "start_date": response["startDate"].isoformat(),
        },
    )
    log_response(logger, payload)
    return payload

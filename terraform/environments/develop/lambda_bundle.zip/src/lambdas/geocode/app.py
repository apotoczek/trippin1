from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)


def handler(event, _context):
    log_event(logger, event, label="event_received")
    origin = event.get("origin", {})
    destination = event.get("destination", {})

    event["origin_geocode"] = {
        "lat": origin.get("lat", 37.7749),
        "lng": origin.get("lng", -122.4194),
    }
    event["destination_geocode"] = {
        "lat": destination.get("lat", 34.0522),
        "lng": destination.get("lng", -118.2437),
    }
    log_response(logger, event)
    return event

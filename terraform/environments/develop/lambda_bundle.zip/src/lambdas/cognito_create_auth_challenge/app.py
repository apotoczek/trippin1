import os
import time
import secrets
import string

import boto3

from src.common.logging_utils import get_logger, log_event, log_response

logger = get_logger(__name__)
sns = boto3.client("sns")


def _get_int(name, default):
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _get_str(name, default):
    value = os.getenv(name)
    return value if value is not None and value != "" else default


def _get_bool(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def _mask_phone(phone_number):
    if not phone_number:
        return ""
    if len(phone_number) <= 4:
        return "***"
    return f"***{phone_number[-4:]}"


def _generate_code(length):
    return "".join(secrets.choice(string.digits) for _ in range(length))


def _render_message(code, ttl_seconds):
    template = _get_str(
        "OTP_MESSAGE_TEMPLATE",
        "Your Trip Planner verification code is {code}. It expires in {ttl_minutes} minutes.",
    )
    ttl_minutes = max(1, (ttl_seconds + 59) // 60)
    try:
        return template.format(code=code, ttl_seconds=ttl_seconds, ttl_minutes=ttl_minutes)
    except Exception:
        return f"Your Trip Planner verification code is {code}. It expires in {ttl_minutes} minutes."


def _send_sms(phone_number, message):
    message_attributes = {
        "AWS.SNS.SMS.SMSType": {
            "DataType": "String",
            "StringValue": _get_str("SMS_TYPE", "Transactional"),
        }
    }

    sender_id = _get_str("SMS_SENDER_ID", "")
    if sender_id:
        message_attributes["AWS.SNS.SMS.SenderID"] = {
            "DataType": "String",
            "StringValue": sender_id,
        }

    sns.publish(
        PhoneNumber=phone_number,
        Message=message,
        MessageAttributes=message_attributes,
    )


def _get_previous_challenge(session):
    if not session:
        return None
    last = session[-1]
    metadata = last.get("challengeMetadata") or ""
    if not metadata.startswith("OTP-"):
        return None
    parts = metadata.split("-")
    if len(parts) != 3:
        return None
    code = parts[1]
    expires_at = parts[2]
    try:
        if int(time.time()) > int(expires_at):
            return None
    except (TypeError, ValueError):
        return None
    return {"code": code, "expires_at": expires_at}


def handler(event, _context):
    log_event(logger, event, label="event_received")
    event.setdefault("request", {})
    event.setdefault("response", {})

    user_attrs = event["request"].get("userAttributes") or {}
    phone_number = user_attrs.get("phone_number")

    if not phone_number:
        raise ValueError("phone_number is required on the user profile")

    otp_length = _get_int("OTP_LENGTH", 6)
    ttl_seconds = _get_int("OTP_TTL_SECONDS", 300)
    static_code = _get_str("OTP_STATIC_CODE", "")
    disable_sms = _get_bool("OTP_DISABLE_SMS", False)

    if static_code:
        code = static_code
        expires_at = str(int(time.time()) + ttl_seconds)
    else:
        previous = _get_previous_challenge(event["request"].get("session") or [])
        if previous:
            code = previous["code"]
            expires_at = previous["expires_at"]
        else:
            code = _generate_code(otp_length)
            expires_at = str(int(time.time()) + ttl_seconds)

    event["response"]["publicChallengeParameters"] = {
        "delivery": "sms",
    }
    event["response"]["privateChallengeParameters"] = {
        "answer": code,
        "expires_at": str(expires_at),
    }
    event["response"]["challengeMetadata"] = f"OTP-{code}-{expires_at}"

    if not disable_sms:
        message = _render_message(code, ttl_seconds)
        logger.info("Sending OTP to %s", _mask_phone(phone_number))
        _send_sms(phone_number, message)
    else:
        logger.info("OTP SMS disabled; using static or generated code for %s", _mask_phone(phone_number))

    log_response(logger, event)
    return event

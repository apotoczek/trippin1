from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)


def handler(event, _context):
    log_event(logger, event, label="event_received")
    event["route"] = {
        "mode": "basic",
        "distance_km": 560,
        "duration_minutes": 380,
    }
    log_response(logger, event)
    return event

from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)


def handler(event, _context):
    log_event(logger, event, label="event_received")
    route = event.get("route", {})
    distance = route.get("distance_km", 0)
    event["score"] = max(0, 100 - int(distance / 10))
    log_response(logger, event)
    return event

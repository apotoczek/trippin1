import json
import os

import boto3
from botocore.exceptions import ClientError

from src.common.responses import json_response
from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)
cognito = boto3.client("cognito-idp")
USER_POOL_CLIENT_ID = os.environ.get("USER_POOL_CLIENT_ID", "")


def handler(event, _context):
    log_event(logger, event, label="event_received")
    body = json.loads(event.get("body") or "{}")
    refresh_token = body.get("refresh_token")

    if not USER_POOL_CLIENT_ID:
        response = json_response(500, {"message": "USER_POOL_CLIENT_ID is not configured"})
        log_response(logger, response)
        return response
    if not refresh_token:
        response = json_response(400, {"message": "refresh_token is required"})
        log_response(logger, response)
        return response

    try:
        response = cognito.initiate_auth(
            ClientId=USER_POOL_CLIENT_ID,
            AuthFlow="REFRESH_TOKEN_AUTH",
            AuthParameters={"REFRESH_TOKEN": refresh_token},
        )
        auth = response.get("AuthenticationResult", {})
        payload = json_response(
            200,
            {
                "access_token": auth.get("AccessToken"),
                "id_token": auth.get("IdToken"),
                "expires_in": auth.get("ExpiresIn"),
                "token_type": auth.get("TokenType"),
            },
        )
        log_response(logger, payload)
        return payload
    except ClientError as exc:
        logger.exception("refresh_auth_failed")
        payload = json_response(401, {"message": str(exc)})
        log_response(logger, payload)
        return payload

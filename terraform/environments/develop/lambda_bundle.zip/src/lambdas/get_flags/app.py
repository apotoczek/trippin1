from src.common.logging_utils import get_logger, log_event, log_response


logger = get_logger(__name__)


def handler(event, _context):
    log_event(logger, event, label="event_received")
    event["flags"] = {
        "use_google_routing": False,
        "enable_weather_risk": False,
    }
    log_response(logger, event)
    return event

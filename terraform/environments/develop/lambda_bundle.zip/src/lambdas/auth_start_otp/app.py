import json
import os
import secrets
import string

import boto3
from botocore.exceptions import ClientError

from src.common.logging_utils import get_logger, log_event, log_response
from src.common.responses import json_response


logger = get_logger(__name__)
cognito = boto3.client("cognito-idp")
USER_POOL_CLIENT_ID = os.environ.get("USER_POOL_CLIENT_ID", "")
USER_POOL_ID = os.environ.get("USER_POOL_ID", "")


def _start_auth(phone_number):
    return cognito.initiate_auth(
        ClientId=USER_POOL_CLIENT_ID,
        AuthFlow="CUSTOM_AUTH",
        AuthParameters={"USERNAME": phone_number},
    )


def _random_password(length=16):
    # Ensure at least one character from each class to satisfy typical Cognito policies.
    charset = {
        "lower": string.ascii_lowercase,
        "upper": string.ascii_uppercase,
        "digit": string.digits,
        "symbol": "!@#$%^&*()-_=+[]{}:,.?",
    }
    required = [
        secrets.choice(charset["lower"]),
        secrets.choice(charset["upper"]),
        secrets.choice(charset["digit"]),
        secrets.choice(charset["symbol"]),
    ]
    all_chars = "".join(charset.values())
    remaining = [secrets.choice(all_chars) for _ in range(max(0, length - len(required)))]
    password = required + remaining
    secrets.SystemRandom().shuffle(password)
    return "".join(password)


def _create_user(phone_number):
    password = _random_password()
    cognito.admin_create_user(
        UserPoolId=USER_POOL_ID,
        Username=phone_number,
        MessageAction="SUPPRESS",
        TemporaryPassword=password,
        UserAttributes=[
            {"Name": "phone_number", "Value": phone_number},
            {"Name": "phone_number_verified", "Value": "true"},
        ],
    )
    cognito.admin_set_user_password(
        UserPoolId=USER_POOL_ID,
        Username=phone_number,
        Password=password,
        Permanent=True,
    )


def _is_user_not_found(exc):
    return exc.response.get("Error", {}).get("Code") == "UserNotFoundException"


def handler(event, _context):
    log_event(logger, event, label="event_received")
    body = event.get("body") or "{}"
    phone_number = json.loads(body).get("phone_number")

    if not USER_POOL_CLIENT_ID:
        response = json_response(500, {"message": "USER_POOL_CLIENT_ID is not configured"})
        log_response(logger, response)
        return response
    if not phone_number:
        response = json_response(400, {"message": "phone_number is required"})
        log_response(logger, response)
        return response

    try:
        response = _start_auth(phone_number)
        payload = json_response(
            200,
            {
                "message": "OTP challenge started",
                "session": response.get("Session"),
                "challenge_name": response.get("ChallengeName"),
            },
        )
        log_response(logger, payload)
        return payload
    except ClientError as exc:
        if _is_user_not_found(exc):
            if not USER_POOL_ID:
                response = json_response(500, {"message": "USER_POOL_ID is not configured"})
                log_response(logger, response)
                return response
            try:
                _create_user(phone_number)
            except ClientError as create_exc:
                code = create_exc.response.get("Error", {}).get("Code")
                if code != "UsernameExistsException":
                    payload = json_response(400, {"message": str(create_exc)})
                    log_response(logger, payload)
                    return payload
                logger.info("User already exists while creating; retrying auth start.")
            try:
                response = _start_auth(phone_number)
                payload = json_response(
                    200,
                    {
                        "message": "OTP challenge started",
                        "session": response.get("Session"),
                        "challenge_name": response.get("ChallengeName"),
                    },
                )
                log_response(logger, payload)
                return payload
            except ClientError as retry_exc:
                logger.exception("auth_start_retry_failed")
                payload = json_response(400, {"message": str(retry_exc)})
                log_response(logger, payload)
                return payload
        logger.exception("auth_start_failed")
        payload = json_response(400, {"message": str(exc)})
        log_response(logger, payload)
        return payload

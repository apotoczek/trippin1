import json
import logging
import os
from typing import Any, Iterable


REDACT_KEYS = {
    "authorization",
    "access_token",
    "id_token",
    "refresh_token",
    "token",
    "password",
    "secret",
    "otp",
    "otp_code",
    "challengeanswer",
    "privatechallengeparameters",
    "challengemetadata",
    "session",
}

ALLOW_KEYS = {
    "challengename",
    "challengeresult",
    "token_type",
    "expires_in",
}

MASK_KEYS = {
    "phone_number",
    "phone",
    "username",
}

def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default


MAX_DEPTH = _env_int("LOG_MAX_DEPTH", 4)
MAX_LIST_ITEMS = _env_int("LOG_MAX_LIST_ITEMS", 20)
MAX_STRING_LENGTH = _env_int("LOG_MAX_STRING_LENGTH", 512)


def get_logger(name: str) -> logging.Logger:
    level_name = os.getenv("LOG_LEVEL", "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)
    logging.basicConfig(level=level)
    return logging.getLogger(name)


def log_event(logger: logging.Logger, event: Any, label: str = "event") -> None:
    try:
        sanitized = sanitize_event(event)
    except Exception as exc:
        logger.warning("event_sanitize_failed: %s", exc)
        sanitized = {"error": "sanitize_failed"}
    logger.info("%s=%s", label, json.dumps(sanitized, default=str))


def log_response(logger: logging.Logger, response: Any, label: str = "response") -> None:
    log_event(logger, response, label=label)


def sanitize_event(event: Any) -> Any:
    return _sanitize(event, depth=0, key=None)


def _sanitize(value: Any, depth: int, key: str | None) -> Any:
    if depth > MAX_DEPTH:
        return "...truncated..."

    if key and _should_redact(key):
        return "***"
    if key and _should_mask(key):
        return _mask_phone(value)

    if isinstance(value, dict):
        return {k: _sanitize(v, depth + 1, k) for k, v in value.items()}
    if isinstance(value, list):
        return _sanitize_list(value, depth)
    if isinstance(value, tuple):
        return _sanitize_list(list(value), depth)
    if isinstance(value, str):
        if key and key.lower() == "body":
            parsed = _maybe_parse_json(value)
            if parsed is not None:
                return _sanitize(parsed, depth + 1, key)
        return _truncate(value)
    return value


def _sanitize_list(values: Iterable[Any], depth: int) -> Any:
    sanitized = []
    count = 0
    for item in values:
        if count >= MAX_LIST_ITEMS:
            sanitized.append("...truncated...")
            break
        sanitized.append(_sanitize(item, depth + 1, None))
        count += 1
    return sanitized


def _should_redact(key: str) -> bool:
    lowered = key.lower()
    if lowered in ALLOW_KEYS:
        return False
    if lowered in REDACT_KEYS:
        return True
    if "token" in lowered and lowered not in ALLOW_KEYS:
        return True
    if "password" in lowered or "secret" in lowered or "otp" in lowered:
        return True
    if "challenge" in lowered and lowered not in ALLOW_KEYS:
        return True
    return False


def _should_mask(key: str) -> bool:
    return key.lower() in MASK_KEYS


def _mask_phone(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    digits = "".join(ch for ch in value if ch.isdigit())
    if len(digits) <= 4:
        return "***"
    return f"***{digits[-4:]}"


def _truncate(value: str) -> str:
    if len(value) <= MAX_STRING_LENGTH:
        return value
    return value[:MAX_STRING_LENGTH] + "..."


def _maybe_parse_json(value: str) -> Any | None:
    stripped = value.strip()
    if not stripped or stripped[0] not in "[{":
        return None
    try:
        return json.loads(stripped)
    except Exception:
        return None

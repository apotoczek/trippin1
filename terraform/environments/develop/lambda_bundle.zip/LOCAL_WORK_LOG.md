# Local Work Log

Purpose: Local-only running summary of work done, what changed, and what’s next. This file is gitignored.

## Summary (Request/Response)

- Initialized scaffold for Step Functions + Lambdas + Cognito auth entrypoints, plus local HTML test UI and SAM local tooling.
- Added Terraform layout (modules + environments) and an HTTPS sign-in page (S3 + CloudFront), plus CI/CD via GitHub Actions.
- Configured AWS backend (S3 state + DynamoDB lock) and IAM OIDC roles for GitHub Actions.
- Created GitHub environments (`develop`, `staging`, `prod`) and populated secrets/vars.
- Deployed `develop` environment and retrieved public URLs.
- Created Cognito User Pool + app clients; switched to a no-secret client for compatibility with current Lambda code.
- Triggered redeploys to apply secret changes.

## Commit History (Files per Commit)

Commit: `27c37d9` (2026-02-20 01:38:14 -0500) by `axp`
Subject: `Add AWS Terraform CI/CD workflow and setup docs`
Files:
`.github/workflows/terraform-cicd.yml`, `README.md`, `docs/cicd_aws_setup.md`, `terraform/environments/develop/versions.tf`, `terraform/environments/prod/versions.tf`, `terraform/environments/staging/versions.tf`, `tools/setup_github_envs.sh`

Commit: `b366305` (2026-02-20 00:50:01 -0500) by `axp`
Subject: `init`
Files:
`LOCAL_SETUP.md`, `README.md`, `docs/debugging.md`, `docs/local_testing.md`

Commit: `6e3ab35` (2026-02-20 00:36:49 -0500) by `axp`
Subject: `init`
Files:
`.gitignore`, `.idea/.gitignore`, `Makefile`, `README.md`, `docs/architecture.md`, `docs/chat_history.md`, `docs/debugging.md`, `docs/local_testing.md`, `docs/terraform_deploy.md`, `env/examples/.env.develop.example`, `env/examples/.env.local.example`, `env/examples/.env.prod.example`, `env/examples/.env.staging.example`, `infra/template.yaml`, `local-ui/index.html`, `requirements.txt`, `src/common/debugging.py`, `src/common/responses.py`, `src/lambdas/auth_refresh/app.py`, `src/lambdas/auth_start_otp/app.py`, `src/lambdas/auth_verify_otp/app.py`, `src/lambdas/geocode/app.py`, `src/lambdas/get_flags/app.py`, `src/lambdas/local_trip_preview/app.py`, `src/lambdas/persist/app.py`, `src/lambdas/route_basic/app.py`, `src/lambdas/score/app.py`, `src/lambdas/start_trip/app.py`, `terraform/README.md`, `terraform/environments/develop/backend.hcl.example`, `terraform/environments/develop/main.tf`, `terraform/environments/develop/outputs.tf`, `terraform/environments/develop/providers.tf`, `terraform/environments/develop/terraform.tfvars.example`, `terraform/environments/develop/variables.tf`, `terraform/environments/develop/versions.tf`, `terraform/environments/prod/backend.hcl.example`, `terraform/environments/prod/main.tf`, `terraform/environments/prod/outputs.tf`, `terraform/environments/prod/providers.tf`, `terraform/environments/prod/terraform.tfvars.example`, `terraform/environments/prod/variables.tf`, `terraform/environments/prod/versions.tf`, `terraform/environments/staging/backend.hcl.example`, `terraform/environments/staging/main.tf`, `terraform/environments/staging/outputs.tf`, `terraform/environments/staging/providers.tf`, `terraform/environments/staging/terraform.tfvars.example`, `terraform/environments/staging/variables.tf`, `terraform/environments/staging/versions.tf`, `terraform/modules/api_auth/main.tf`, `terraform/modules/api_auth/outputs.tf`, `terraform/modules/api_auth/variables.tf`, `terraform/modules/signin_site/main.tf`, `terraform/modules/signin_site/outputs.tf`, `terraform/modules/signin_site/variables.tf`, `tests/test_local_trip_preview.py`, `tests/test_smoke.py`, `tools/preflight_debug.py`, `tools/test_local_sam.sh`, `web/signin/index.html`

## AWS/GitHub Actions Work Completed (Out-of-band)

- AWS account: `596833524375`, region: `us-east-1`
- Terraform state bucket: `trip-planner-tfstate-596833524375`
- Terraform lock table: `trip-planner-tf-locks`
- IAM roles created:
  - `GitHubActionsTripPlannerDevelop`
  - `GitHubActionsTripPlannerStaging`
  - `GitHubActionsTripPlannerProd`
- GitHub environments created: `develop`, `staging`, `prod`
- GitHub secrets/vars populated for each environment
- Cognito User Pool: `us-east-1_GWaAdJg7v`
- Cognito app clients:
  - Secret client (caused SECRET_HASH error): `5vm91745gbbi60es36ph14opos`
  - No-secret client (intended for current Lambda code): `4fbb847j30p05lp1uer0b215v6`

## Current Working Tree Notes (Uncommitted)

- Uncommitted Terraform edits adding `auth_verify`, `auth_refresh`, and `start_trip` routes, plus `trip_workflow` module and `wait_for_deployment=false` for CloudFront.
- Untracked: `.idea/*`, `.terraform.lock.hcl` files, and `terraform/modules/trip_workflow/*`.

## Next Steps (Not Done Yet)

- Decide whether to keep/commit the Terraform changes (`api_auth` expansions, `trip_workflow`, CloudFront wait tweak). If yes, commit and push.
- Verify the deployed Lambda env var `USER_POOL_CLIENT_ID` is now the no-secret client.
- Implement Cognito custom challenge triggers (Define/Create/Verify Auth Challenge Lambdas) and attach to user pool.
- Configure SMS settings for Cognito (SNS role + SMS configuration) if OTP via SMS is required.
- Update sign-in flow to call `/auth/verify` once OTP verification is implemented.

## Manual Tasks (Console/Web)

AWS Console:
- Cognito User Pool: configure SMS (SNS role) or switch to email-based flow.
- Cognito User Pool: add custom challenge triggers once Lambdas exist.
- Optional: set password policy, MFA, and domain settings.

GitHub Web:
- Ensure environment protection rules for `prod` are set (approvals).
- Verify secrets for `staging`/`prod` once those environments are ready.
